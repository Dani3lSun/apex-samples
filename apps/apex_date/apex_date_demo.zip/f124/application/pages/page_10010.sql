prompt --application/pages/page_10010
begin
--   Manifest
--     PAGE: 10010
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-19'
,p_default_workspace_id=>7805442713131290
,p_default_application_id=>124
,p_default_id_offset=>246740966229482281
,p_default_owner=>'DANIEL'
);
wwv_flow_api.create_page(
 p_id=>10010
,p_user_interface_id=>wwv_flow_api.id(250092113100526361)
,p_name=>'About'
,p_alias=>'HELP'
,p_step_title=>'About'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(250095420269526408)
,p_required_patch=>wwv_flow_api.id(250094167242526403)
,p_protection_level=>'C'
,p_help_text=>'All application help text can be accessed from this page. The links in the "Documentation" region give a much more in-depth explanation of the application''s features and functionality.'
,p_last_updated_by=>'DAHOCHLE'
,p_last_upd_yyyymmddhh24miss=>'20210311213028'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(250104076953526483)
,p_plug_name=>'About Page'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--padded:t-ContentBlock--h1:t-ContentBlock--lightBG'
,p_plug_template=>wwv_flow_api.id(249981540139526239)
,p_plug_display_sequence=>20
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This is a demo app showcasing the new client side JavaScript library <strong>apex.date</strong> introduced with APEX 21.2</p>',
'<p>This library can be used to format & parse JavaScript date objects, to manipulate dates and has some useful helper functions as well.</p>'))
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_api.component_end;
end;
/
