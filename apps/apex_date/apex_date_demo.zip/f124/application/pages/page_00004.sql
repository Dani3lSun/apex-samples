prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-19'
,p_default_workspace_id=>7805442713131290
,p_default_application_id=>124
,p_default_id_offset=>246740966229482281
,p_default_owner=>'DANIEL'
);
wwv_flow_api.create_page(
 p_id=>4
,p_user_interface_id=>wwv_flow_api.id(250092113100526361)
,p_name=>'Date Comparison'
,p_alias=>'DATE-COMPARISON'
,p_step_title=>'Date Comparison'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'#IMAGE_PREFIX#libraries/prismjs/1.24.1/prism.min.js'
,p_css_file_urls=>'#IMAGE_PREFIX#libraries/prismjs/1.24.1/prism.min.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* fix prismjs highlighting operators */',
'.token.operator {',
'    background: unset;',
'}',
'',
'/* fix textarea whitespace monospace */',
'textarea {',
'    font-family: monospace;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'DAHOCHLE'
,p_last_upd_yyyymmddhh24miss=>'20210828212024'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(255041794951568598)
,p_plug_name=>'Date Comparison'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(250007403466526257)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(255042994011568610)
,p_plug_name=>'Info'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(249985133451526241)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre><code class="language-javascript">',
'// parse values from date pickers as dates',
'var date1 = apex.date.parse( apex.item( "P4_DATEPICKER1" ).getValue(), "YYYY-MON-DD HH24:MI" ),',
'    date2 = apex.date.parse( apex.item( "P4_DATEPICKER2" ).getValue(), "YYYY-MON-DD HH24:MI" ),',
'    date3 = apex.date.parse( apex.item( "P4_DATEPICKER3" ).getValue(), "YYYY-MON-DD HH24:MI" );',
'',
'// check if date 1 < date 2',
'var isDateBefore = apex.date.isBefore( date1, date2, apex.date.UNIT.SECOND );',
'',
'// check if date 1 > date 2',
'var isDateAfter = apex.date.isAfter( date1, date2, apex.date.UNIT.MINUTE );',
'',
'// check if date 1 = date 2',
'var isDateSame = apex.date.isSame( date1, date2, apex.date.UNIT.SECOND );',
'',
'// check if date 1 <= date 2',
'var isDateSameBefore = apex.date.isSameOrBefore( date1, date2, apex.date.UNIT.HOUR );',
'',
'// check if date 1 >= date 2',
'var isDateSameAfter = apex.date.isSameOrAfter( date1, date2, apex.date.UNIT.HOUR );',
'',
'// check if date 1 > date 2 & date 1 < date 3',
'var isDateBetween = apex.date.isBetween( date1, date2, date3, apex.date.UNIT.SECOND );',
'',
'// get the minimum date of a given dates array',
'var minDate = apex.date.min( date1, date2, date3 );',
'',
'// get the maximum date of a given dates array',
'var maxDate = apex.date.max( date1, date2, date3 );',
'</code></pre>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(255047426275576417)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(249983913675526240)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(249945303414526207)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(250068978872526313)
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(251643067739513521)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(255041794951568598)
,p_button_name=>'COMPARE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(250067696679526311)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Compare'
,p_button_position=>'COPY'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-exchange'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(250144665932537415)
,p_name=>'P4_DATEPICKER2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(255041794951568598)
,p_item_default=>'to_char(sysdate, ''YYYY-MON-DD HH24:MI'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Date 2'
,p_format_mask=>'YYYY-MON-DD HH24:MI'
,p_display_as=>'NATIVE_DATE_PICKER_JET'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(250065080734526307)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(250144678102537416)
,p_name=>'P4_DATEPICKER3'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(255041794951568598)
,p_item_default=>'to_char(sysdate, ''YYYY-MON-DD HH24:MI'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Date 3'
,p_format_mask=>'YYYY-MON-DD HH24:MI'
,p_display_as=>'NATIVE_DATE_PICKER_JET'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(250065080734526307)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(251643532805513521)
,p_name=>'P4_DATEPICKER1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(255041794951568598)
,p_item_default=>'to_char(sysdate, ''YYYY-MON-DD HH24:MI'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Date 1'
,p_format_mask=>'YYYY-MON-DD HH24:MI'
,p_display_as=>'NATIVE_DATE_PICKER_JET'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(250065080734526307)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(251644282245513523)
,p_name=>'P4_UNIT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(255041794951568598)
,p_item_default=>'day'
,p_prompt=>'Unit'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'APEX_DATE_UNITS'
,p_lov=>'.'||wwv_flow_api.id(250149184593567910)||'.'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(250065080734526307)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(251644725995513523)
,p_name=>'P4_RESULT'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(255041794951568598)
,p_prompt=>'Result'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>10
,p_tag_attributes=>'readonly="readonly"'
,p_field_template=>wwv_flow_api.id(250065080734526307)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(251645683486513526)
,p_name=>'Compare Dates'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(251643067739513521)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(251646212119513528)
,p_event_id=>wwv_flow_api.id(251645683486513526)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var date1 = apex.date.parse( apex.item( "P4_DATEPICKER1" ).getValue(), "YYYY-MON-DD HH24:MI" ),',
'    date2 = apex.date.parse( apex.item( "P4_DATEPICKER2" ).getValue(), "YYYY-MON-DD HH24:MI" ),',
'    date3 = apex.date.parse( apex.item( "P4_DATEPICKER3" ).getValue(), "YYYY-MON-DD HH24:MI" ),',
'    unit = apex.item( "P4_UNIT" ).getValue(),',
'    result = "";',
'',
'result = result + "isBefore      : " + ( apex.date.isBefore( date1, date2, unit ) ? "Yes" : "No" ) + "\n";',
'result = result + "isAfter       : " + ( apex.date.isAfter( date1, date2, unit ) ? "Yes" : "No" ) + "\n";',
'result = result + "isSame        : " + ( apex.date.isSame( date1, date2, unit ) ? "Yes" : "No" ) + "\n";',
'result = result + "isSameOrBefore: " + ( apex.date.isSameOrBefore( date1, date2, unit ) ? "Yes" : "No" ) + "\n";',
'result = result + "isSameOrAfter : " + ( apex.date.isSameOrAfter( date1, date2, unit ) ? "Yes" : "No" ) + "\n";',
'result = result + "isBetween     : " + ( apex.date.isBetween( date1, date2, date3, unit ) ? "Yes" : "No" ) + "\n";',
'result = result + "min           : " + apex.date.format( apex.date.min( date1, date2, date3 ), "YYYY-MON-DD HH24:MI" ) + "\n";',
'result = result + "max           : " + apex.date.format( apex.date.max( date1, date2, date3 ), "YYYY-MON-DD HH24:MI" ) + "\n";',
'',
'apex.item( "P4_RESULT" ).setValue( result );'))
);
wwv_flow_api.component_end;
end;
/
