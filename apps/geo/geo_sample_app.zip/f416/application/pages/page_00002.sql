prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-19'
,p_default_workspace_id=>7805442713131290
,p_default_application_id=>416
,p_default_id_offset=>0
,p_default_owner=>'DANIEL'
);
wwv_flow_api.create_page(
 p_id=>2
,p_user_interface_id=>wwv_flow_api.id(340183366392470071)
,p_name=>'Display Map'
,p_alias=>'DISPLAY-MAP'
,p_step_title=>'Display Map'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'DANIEL'
,p_last_upd_yyyymmddhh24miss=>'20211209051429'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(340194064403470208)
,p_plug_name=>'Display Map'
,p_icon_css_classes=>'app-icon'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(340063933956469874)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(340231103543557501)
,p_plug_name=>'Container'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(340086058668469906)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_display_column=>3
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(340231226702557502)
,p_name=>'P2_MAP_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(340231103543557501)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_json.stringify( addr_location )',
'  from eba_spatial_addresses',
' where id = 1'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Map 1'
,p_display_as=>'NATIVE_DISPLAY_MAP'
,p_attribute_01=>'default'
,p_attribute_02=>'14'
,p_attribute_03=>'Y'
,p_attribute_05=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>Oracle Corporation</strong><br>',
'500, Oracle Parkway Redwood City'))
,p_attribute_06=>'Y'
,p_attribute_07=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(340231371009557503)
,p_name=>'P2_MAP_2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(340231103543557501)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_json.stringify( addr_location )',
'  from eba_spatial_addresses',
' where id = 2'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Map 2'
,p_display_as=>'NATIVE_DISPLAY_MAP'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(340156174563470020)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'world-map'
,p_attribute_02=>'14'
,p_attribute_03=>'Y'
,p_attribute_04=>'#ff0000'
,p_attribute_05=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>Oracle Deutschland B.V. & Co KG</strong><br>',
unistr('Riesstr. 25 80992 M\00FCnchen')))
,p_attribute_06=>'Y'
,p_attribute_07=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(340231425211557504)
,p_name=>'P2_MAP_3'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(340231103543557501)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_json.stringify( addr_location )',
'  from eba_spatial_addresses',
' where id = 2'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Map 3'
,p_display_as=>'NATIVE_DISPLAY_MAP'
,p_field_template=>wwv_flow_api.id(340156174563470020)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'osm-dark-matter'
,p_attribute_02=>'14'
,p_attribute_03=>'Y'
,p_attribute_04=>'#ff0000'
,p_attribute_05=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>Oracle Deutschland B.V. & Co KG</strong><br>',
unistr('Riesstr. 25 80992 M\00FCnchen')))
,p_attribute_06=>'Y'
,p_attribute_07=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(340231546866557505)
,p_name=>'P2_MAP_4'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(340231103543557501)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_json.stringify( addr_location )',
'  from eba_spatial_addresses',
' where id = 2'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Map 4'
,p_display_as=>'NATIVE_DISPLAY_MAP'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(340156174563470020)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'osm-positron'
,p_attribute_02=>'14'
,p_attribute_03=>'Y'
,p_attribute_04=>'#ff0000'
,p_attribute_05=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>Oracle Deutschland B.V. & Co KG</strong><br>',
unistr('Riesstr. 25 80992 M\00FCnchen')))
,p_attribute_06=>'Y'
,p_attribute_07=>'Y'
);
wwv_flow_api.component_end;
end;
/
