prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-19'
,p_default_workspace_id=>7805442713131290
,p_default_application_id=>124
,p_default_id_offset=>246740966229482281
,p_default_owner=>'DANIEL'
);
wwv_flow_api.create_page(
 p_id=>3
,p_user_interface_id=>wwv_flow_api.id(250092113100526361)
,p_name=>'Date Formatting & Parsing'
,p_alias=>'DATE-FORMATTING-PARSING'
,p_step_title=>'Date Formatting & Parsing'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'#IMAGE_PREFIX#libraries/prismjs/1.24.1/prism.min.js'
,p_css_file_urls=>'#IMAGE_PREFIX#libraries/prismjs/1.24.1/prism.min.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* fix prismjs highlighting operators */',
'.token.operator {',
'    background: unset;',
'}',
'',
'/* fix textarea whitespace monospace */',
'textarea {',
'    font-family: monospace;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'DAHOCHLE'
,p_last_upd_yyyymmddhh24miss=>'20210828212001'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(250143146600537400)
,p_plug_name=>'Date Parsing'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(250007403466526257)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(250143793609537407)
,p_plug_name=>'Relative Date Time'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(250007403466526257)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(254541849542763162)
,p_plug_name=>'Date Formatting'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(250007403466526257)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(254543048602763174)
,p_plug_name=>'Info'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(249985133451526241)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre><code class="language-javascript">',
'// date parsing',
'var date = apex.date.parse( "2021-03-11 15:30", "YYYY-MM-DD HH24:MI" );',
'var date = apex.date.parse( "11.03.2021 15:30:45", "DD.MM.YYYY HH24:MI:SS" );',
'var date = apex.date.parse( "2021/03/11", "YYYY/MM/DD" );',
'',
'// date formatting',
'var dateString = apex.date.format( date, "YYYY-MM-DD HH24:MI" );',
'var dateString = apex.date.format( date, "Day, DD Month YYYY" );',
'var dateString = apex.date.format( date, "YYYY, IW" );',
'var dateString = apex.date.format( date, "DL", "de-de" );',
'',
'// relative date / time as words',
'var dateString = apex.date.since( date );',
'var dateString = apex.date.since( date, true );',
'</code></pre>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(254547480866770981)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(249983913675526240)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(249945303414526207)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(250068978872526313)
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(250142836338537397)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(254541849542763162)
,p_button_name=>'FORMAT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(250067696679526311)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Format'
,p_button_position=>'COPY'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-format'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(250143552544537404)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(250143146600537400)
,p_button_name=>'PARSE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(250067696679526311)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Parse'
,p_button_position=>'COPY'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-format'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(250144249039537411)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(250143793609537407)
,p_button_name=>'RELATIVE_DATE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(250067696679526311)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Get Relative Date'
,p_button_position=>'COPY'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-format'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(250143249275537401)
,p_name=>'P3_DATE_STRING'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(250143146600537400)
,p_item_default=>'to_char(sysdate, ''YYYY-MON-DD HH24:MI:SS'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Date'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(250065080734526307)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(250143344545537402)
,p_name=>'P3_FORMAT_MASK2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(250143146600537400)
,p_item_default=>'YYYY-MON-DD HH24:MI:SS'
,p_prompt=>'Format Mask'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(250065080734526307)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(250143444489537403)
,p_name=>'P3_RESULT2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(250143146600537400)
,p_prompt=>'Result'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_tag_attributes=>'readonly="readonly"'
,p_field_template=>wwv_flow_api.id(250065080734526307)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(250143899181537408)
,p_name=>'P3_DATE_PICKER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(250143793609537407)
,p_item_default=>'to_char(sysdate + round(dbms_random.value(1, 500)), ''YYYY-MON-DD HH24:MI'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Date Picker'
,p_format_mask=>'YYYY-MON-DD HH24:MI'
,p_display_as=>'NATIVE_DATE_PICKER_JET'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(250065080734526307)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(250144072167537410)
,p_name=>'P3_RESULT3'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(250143793609537407)
,p_prompt=>'Result'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_tag_attributes=>'readonly="readonly"'
,p_field_template=>wwv_flow_api.id(250065080734526307)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(250144559270537414)
,p_name=>'P3_SHORT_YN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(250143793609537407)
,p_item_default=>'N'
,p_prompt=>'Short Version?'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(250065080734526307)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(251143553423708090)
,p_name=>'P3_DATE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(254541849542763162)
,p_item_default=>'to_char(sysdate, ''YYYY-MON-DD HH24:MI:SS'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Date'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(250065080734526307)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(251143898018708091)
,p_name=>'P3_FORMAT_MASK'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(254541849542763162)
,p_item_default=>'YYYY-MON-DD HH24:MI:SS'
,p_prompt=>'Format Mask'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(250065080734526307)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_show_quick_picks=>'Y'
,p_quick_pick_label_01=>'YYYY/MM/DD'
,p_quick_pick_value_01=>'YYYY/MM/DD'
,p_quick_pick_label_02=>'DD.MM.YYYY HH24:MI'
,p_quick_pick_value_02=>'DD.MM.YYYY HH24:MI'
,p_quick_pick_label_03=>'Day, DD Month YYYY'
,p_quick_pick_value_03=>'Day, DD Month YYYY'
,p_quick_pick_label_04=>'YYYY, IW'
,p_quick_pick_value_04=>'YYYY, IW'
,p_quick_pick_label_05=>'DS'
,p_quick_pick_value_05=>'DS'
,p_quick_pick_label_06=>'DL'
,p_quick_pick_value_06=>'DL'
,p_quick_pick_label_07=>'YYYYMMDDHH24MISS'
,p_quick_pick_value_07=>'YYYYMMDDHH24MISS'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(251144677810708092)
,p_name=>'P3_RESULT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(254541849542763162)
,p_prompt=>'Result'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_tag_attributes=>'readonly="readonly"'
,p_field_template=>wwv_flow_api.id(250065080734526307)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(250142878606537398)
,p_name=>'Format Date'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(250142836338537397)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(250143060335537399)
,p_event_id=>wwv_flow_api.id(250142878606537398)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var date = apex.date.parse( apex.item( "P3_DATE" ).getValue(), "YYYY-MON-DD HH24:MI:SS" ),',
'    formatMask = apex.item( "P3_FORMAT_MASK" ).getValue(),',
'    result = "";',
'',
'result = apex.date.format( date, formatMask );',
'',
'apex.item( "P3_RESULT" ).setValue( result );'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(250143642994537405)
,p_name=>'Parse Date'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(250143552544537404)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(250143726725537406)
,p_event_id=>wwv_flow_api.id(250143642994537405)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var date,',
'    dateString = apex.item( "P3_DATE_STRING" ).getValue(),',
'    formatMask = apex.item( "P3_FORMAT_MASK2" ).getValue(),',
'    result = "";',
'',
'try {',
'    date = apex.date.parse( dateString, formatMask ),',
'    result = apex.date.format( date, "YYYY-MON-DD HH24:MI:SS" );',
'    apex.item( "P3_RESULT2" ).setValue( "Success: " + result );',
'} catch( err ) {',
'    apex.item( "P3_RESULT2" ).setValue( err );',
'}'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(250144358090537412)
,p_name=>'Relative Date'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(250144249039537411)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(250144406920537413)
,p_event_id=>wwv_flow_api.id(250144358090537412)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var date = apex.date.parse( apex.item( "P3_DATE_PICKER" ).getValue(), "YYYY-MON-DD HH24:MI" ),',
'    short = apex.item( "P3_SHORT_YN" ).getValue() === "Y" ? true : false,',
'    result = "";',
'',
'result = apex.date.since( date, short );',
'',
'apex.item( "P3_RESULT3" ).setValue( result );'))
);
wwv_flow_api.component_end;
end;
/
