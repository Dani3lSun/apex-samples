prompt --application/shared_components/navigation/lists/page_navigation
begin
--   Manifest
--     LIST: Page Navigation
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-19'
,p_default_workspace_id=>7805442713131290
,p_default_application_id=>416
,p_default_id_offset=>0
,p_default_owner=>'DANIEL'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(340196471093470222)
,p_name=>'Page Navigation'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(340196793250470222)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Display Map'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&APP_SESSION.::&DEBUG.:'
,p_list_item_icon=>'fa-map-o'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(340197145741470223)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'miniMap'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&APP_SESSION.::&DEBUG.:'
,p_list_item_icon=>'fa-map-markers'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
