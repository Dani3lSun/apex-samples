prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-19'
,p_default_workspace_id=>7805442713131290
,p_default_application_id=>124
,p_default_id_offset=>246740966229482281
,p_default_owner=>'DANIEL'
);
wwv_flow_api.create_page(
 p_id=>5
,p_user_interface_id=>wwv_flow_api.id(250092113100526361)
,p_name=>'Miscellaneous'
,p_alias=>'MISCELLANEOUS'
,p_step_title=>'Miscellaneous'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'#IMAGE_PREFIX#libraries/prismjs/1.24.1/prism.min.js'
,p_css_file_urls=>'#IMAGE_PREFIX#libraries/prismjs/1.24.1/prism.min.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* fix prismjs highlighting operators */',
'.token.operator {',
'    background: unset;',
'}',
'',
'/* fix textarea whitespace monospace */',
'textarea {',
'    font-family: monospace;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'DAHOCHLE'
,p_last_upd_yyyymmddhh24miss=>'20210828212049'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(260442203489438815)
,p_plug_name=>'Miscellaneous'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(250007403466526257)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(260443402549438827)
,p_plug_name=>'Info'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(249985133451526241)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre><code class="language-javascript">',
'// parse values from date pickers as dates',
'var date = apex.date.parse( apex.item( "P5_DATEPICKER" ).getValue(), "YYYY-MON-DD HH24:MI" ),',
'    now = new Date();',
'',
'// get ISO week number',
'var week = apex.date.ISOWeek( date );',
'',
'// get week of month',
'var week = apex.date.weekOfMonth( date );',
'',
'// get total days of month',
'var days = apex.date.daysInMonth( date );',
'',
'// get day of week',
'var day = apex.date.dayOfWeek( date );',
'',
'// get day of year',
'var day = apex.date.getDayOfYear( date );',
'',
'// get seconds past midnight',
'var seconds = apex.date.secondsPastMidnight( date );',
'',
'// get first of month as date object',
'var first = apex.date.firstOfMonth( date );',
'',
'// get last of month as date object',
'var last = apex.date.lastOfMonth( date );',
'',
'// get start of day as date object',
'var start = apex.date.startOfDay( date );',
'',
'// get end of day as date object',
'var end = apex.date.endOfDay( date );',
'',
'// get months between 2 dates',
'var months = apex.date.monthsBetween( now, date );',
'',
'// get ISO 8601 string (without timezone)',
'var isoString = apex.date.toISOString( date );',
'',
'// check if it''s a leap year',
'var isLeapYear = apex.date.isLeapYear( date );',
'</code></pre>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(260447834813446634)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(249983913675526240)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(249945303414526207)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(250068978872526313)
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(252142702565352521)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(260442203489438815)
,p_button_name=>'EXECUTE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(250067696679526311)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Execute'
,p_button_position=>'COPY'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-play'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252143142237352521)
,p_name=>'P5_DATEPICKER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(260442203489438815)
,p_item_default=>'to_char(sysdate, ''YYYY-MON-DD HH24:MI'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Date 1'
,p_format_mask=>'YYYY-MON-DD HH24:MI'
,p_display_as=>'NATIVE_DATE_PICKER_JET'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(250065080734526307)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252144713579352524)
,p_name=>'P5_RESULT'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(260442203489438815)
,p_prompt=>'Result'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>15
,p_tag_attributes=>'readonly="readonly"'
,p_field_template=>wwv_flow_api.id(250065080734526307)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(252145670567352526)
,p_name=>'Execute Functions'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(252142702565352521)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(252146246721352528)
,p_event_id=>wwv_flow_api.id(252145670567352526)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var date = apex.date.parse( apex.item( "P5_DATEPICKER" ).getValue(), "YYYY-MON-DD HH24:MI" ),',
'    now = new Date(),',
'    result = "";',
'',
'result = result + "ISOWeek            : " + apex.date.ISOWeek( date ) + "\n";',
'result = result + "weekOfMonth        : " + apex.date.weekOfMonth( date ) + "\n";',
'result = result + "daysInMonth        : " + apex.date.daysInMonth( date ) + "\n";',
'result = result + "dayOfWeek          : " + apex.date.dayOfWeek( date ) + "\n";',
'result = result + "getDayOfYear       : " + apex.date.getDayOfYear( date ) + "\n";',
'result = result + "secondsPastMidnight: " + apex.date.secondsPastMidnight( date ) + "\n";',
'result = result + "firstOfMonth       : " + apex.date.format( apex.date.firstOfMonth( date ), "DL" ) + "\n";',
'result = result + "lastOfMonth        : " + apex.date.format( apex.date.lastOfMonth( date ), "DL" ) + "\n";',
'result = result + "startOfDay         : " + apex.date.format( apex.date.startOfDay( date ), "YYYY-MON-DD HH24:MI:SS" ) + "\n";',
'result = result + "endOfDay           : " + apex.date.format( apex.date.endOfDay( date ), "YYYY-MON-DD HH24:MI:SS" ) + "\n";',
'result = result + "monthsBetween      : " + apex.date.monthsBetween( now, date ) + "\n";',
'result = result + "toISOString        : " + apex.date.toISOString( date ) + "\n";',
'result = result + "isLeapYear         : " + ( apex.date.isLeapYear( date ) ? "Yes" : "No" ) + "\n";',
'',
'apex.item( "P5_RESULT" ).setValue( result );'))
);
wwv_flow_api.component_end;
end;
/
