prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-19'
,p_default_workspace_id=>7805442713131290
,p_default_application_id=>124
,p_default_id_offset=>246740966229482281
,p_default_owner=>'DANIEL'
);
wwv_flow_api.create_page(
 p_id=>2
,p_user_interface_id=>wwv_flow_api.id(250092113100526361)
,p_name=>'Date Manipulation'
,p_alias=>'DATE-MANIPULATION'
,p_step_title=>'Date Manipulation'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'#IMAGE_PREFIX#libraries/prismjs/1.24.1/prism.min.js'
,p_css_file_urls=>'#IMAGE_PREFIX#libraries/prismjs/1.24.1/prism.min.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* fix prismjs highlighting operators */',
'.token.operator {',
'    background: unset;',
'}',
'',
'/* fix textarea whitespace monospace */',
'textarea {',
'    font-family: monospace;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'DAHOCHLE'
,p_last_upd_yyyymmddhh24miss=>'20210828211934'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(250141385555537383)
,p_plug_name=>'Date Manipulation'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(250007403466526257)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(250142584615537395)
,p_plug_name=>'Info'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(249985133451526241)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre><code class="language-javascript">',
'// create a new date object',
'var date = new Date();',
'',
'// add or subtract a day',
'apex.date.add( date, 1, apex.date.UNIT.DAY );',
'apex.date.subtract( date, 1, apex.date.UNIT.DAY );',
'',
'// add or subtract a month',
'apex.date.add( date, 1, apex.date.UNIT.MONTH );',
'apex.date.subtract( date, 1, apex.date.UNIT.MONTH );',
'',
'// clone a date to not change the original object',
'var clonedDate = apex.date.clone( date );',
'',
'// available units',
'apex.date.UNIT = {',
'    MILLISECOND: "millisecond",',
'    SECOND: "second",',
'    MINUTE: "minute",',
'    HOUR: "hour",',
'    DAY: "day",',
'    WEEK: "week",',
'    MONTH: "month",',
'    YEAR: "year"',
'};',
'</code></pre>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(250147016879545202)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(249983913675526240)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(249945303414526207)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(250068978872526313)
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(250141980781537389)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(250141385555537383)
,p_button_name=>'ADD'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(250067696679526311)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add'
,p_button_position=>'COPY'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-plus-circle'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(250141957103537388)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(250141385555537383)
,p_button_name=>'SUBTRACT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_api.id(250067696679526311)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Subtract'
,p_button_position=>'COPY'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-minus-circle'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(250141526975537384)
,p_name=>'P2_DATEPICKER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(250141385555537383)
,p_item_default=>'to_char(sysdate, ''YYYY-MON-DD HH24:MI'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Date Picker'
,p_format_mask=>'YYYY-MON-DD HH24:MI'
,p_display_as=>'NATIVE_DATE_PICKER_JET'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(250065080734526307)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(250141627498537385)
,p_name=>'P2_AMOUNT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(250141385555537383)
,p_item_default=>'1'
,p_prompt=>'Amount'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(250065080734526307)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(250141709637537386)
,p_name=>'P2_UNIT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(250141385555537383)
,p_prompt=>'Unit'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'APEX_DATE_UNITS'
,p_lov=>'.'||wwv_flow_api.id(250149184593567910)||'.'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(250065080734526307)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(250141844488537387)
,p_name=>'P2_RESULT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(250141385555537383)
,p_prompt=>'Result'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_tag_attributes=>'readonly="readonly"'
,p_field_template=>wwv_flow_api.id(250065080734526307)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(250142085606537390)
,p_name=>'Add Date'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(250141980781537389)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(250142180308537391)
,p_event_id=>wwv_flow_api.id(250142085606537390)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var date = apex.date.parse( apex.item( "P2_DATEPICKER" ).getValue(), "YYYY-MON-DD HH24:MI" ),',
'    amount = parseInt( apex.item( "P2_AMOUNT" ).getValue(), 10 ),',
'    unit = apex.item( "P2_UNIT" ).getValue(),',
'    result = "";',
'',
'apex.date.add( date, amount, unit );',
'',
'result = apex.date.format( date, "YYYY-MON-DD HH24:MI:SS" );',
'',
'apex.item( "P2_RESULT" ).setValue( result );'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(250142412330537393)
,p_name=>'Subtract Date'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(250141957103537388)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(250142525385537394)
,p_event_id=>wwv_flow_api.id(250142412330537393)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var date = apex.date.parse( apex.item( "P2_DATEPICKER" ).getValue(), "YYYY-MON-DD HH24:MI" ),',
'    amount = parseInt( apex.item( "P2_AMOUNT" ).getValue(), 10 ),',
'    unit = apex.item( "P2_UNIT" ).getValue(),',
'    result = "";',
'',
'apex.date.subtract( date, amount, unit );',
'',
'result = apex.date.format( date, "YYYY-MON-DD HH24:MI:SS" );',
'',
'apex.item( "P2_RESULT" ).setValue( result );'))
);
wwv_flow_api.component_end;
end;
/
