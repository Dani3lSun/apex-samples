prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-19'
,p_default_workspace_id=>7805442713131290
,p_default_application_id=>416
,p_default_id_offset=>0
,p_default_owner=>'DANIEL'
);
wwv_flow_api.create_page(
 p_id=>4
,p_user_interface_id=>wwv_flow_api.id(340183366392470071)
,p_name=>'Geocoded Report'
,p_alias=>'GEOCODED-REPORT'
,p_step_title=>'Geocoded Report'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'DANIEL'
,p_last_upd_yyyymmddhh24miss=>'20211117061720'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(392011092345808988)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(340081738319469899)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'EBA_SPATIAL_ADDRESSES'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Report 1'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(392011470295808989)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:RP:P5_ID:\#ID#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'DANIEL'
,p_internal_uid=>392011470295808989
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(392011554966809011)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(392011830665809059)
,p_db_column_name=>'ADDR_NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Addr Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(392012218024809059)
,p_db_column_name=>'ADDR_STREET'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Addr Street'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(392012652409809059)
,p_db_column_name=>'ADDR_POSTAL_CODE'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Addr Postal Code'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(392013063640809060)
,p_db_column_name=>'ADDR_CITY'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Addr City'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(392013496981809060)
,p_db_column_name=>'ADDR_STATE'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Addr State'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(392013818432809060)
,p_db_column_name=>'ADDR_COUNTRY'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Addr Country'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(392014221809809061)
,p_db_column_name=>'ADDR_TYPE'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Addr Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(392014695673809061)
,p_db_column_name=>'OWNER'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Owner'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(392015088700809061)
,p_db_column_name=>'DATETIME'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Datetime'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(392015401566809062)
,p_db_column_name=>'ADDR_LOCATION'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Addr Location'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(392024239721821471)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3920243'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:ADDR_NAME:ADDR_STREET:ADDR_POSTAL_CODE:ADDR_CITY:ADDR_STATE:ADDR_COUNTRY:ADDR_TYPE:OWNER:DATETIME:ADDR_LOCATION'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(392016661595809084)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(392011092345808988)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(340158625274470030)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:5'
);
wwv_flow_api.component_end;
end;
/
