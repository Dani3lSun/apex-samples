prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-19'
,p_default_workspace_id=>7805442713131290
,p_default_application_id=>416
,p_default_id_offset=>0
,p_default_owner=>'DANIEL'
);
wwv_flow_api.create_page(
 p_id=>3
,p_user_interface_id=>wwv_flow_api.id(340183366392470071)
,p_name=>'miniMap'
,p_alias=>'MINIMAP'
,p_step_title=>'miniMap'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'#IMAGE_PREFIX#libraries/apex/#MIN_DIRECTORY#widget.miniMap#MIN#.js'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'DANIEL'
,p_last_upd_yyyymmddhh24miss=>'20211014031747'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(340195601339470210)
,p_plug_name=>'miniMap'
,p_icon_css_classes=>'app-icon'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(340063933956469874)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1026963214126005922)
,p_plug_name=>'miniMap with options'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(340086058668469906)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="optionsMap"',
'     style="width:100%;height:600px"></div>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1026964004449006923)
,p_plug_name=>'miniMap with data attributes'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(340086058668469906)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="attributesMap"',
'     data-center="[-122.26516, 37.52938]"',
'     data-background="osm-bright"',
'     data-zoom="14"',
'     data-marker="true"',
'     data-marker-color="red"',
'     data-controls="true"',
'     data-interactive="false"',
'     data-tooltip="Oracle Redwood Shores"',
'     style="width:100%;height:600px">',
'</div>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1026965537434007792)
,p_plug_name=>'miniMap with Cards'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(340038714181469852)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select esa.*,',
'       esa.addr_street || '' '' || esa.addr_postal_code || '' '' || esa.addr_city as address_display,',
'       to_char(esa.addr_location.sdo_point.x, ''9990D9999'') as longitude,',
'       to_char(esa.addr_location.sdo_point.y, ''9990D9999'') as latitude',
'  from eba_spatial_addresses esa'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_show_total_row_count=>false
);
wwv_flow_api.create_card(
 p_id=>wwv_flow_api.id(340225841119515787)
,p_region_id=>wwv_flow_api.id(1026965537434007792)
,p_layout_type=>'GRID'
,p_grid_column_count=>3
,p_title_adv_formatting=>false
,p_title_column_name=>'ADDR_NAME'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'ADDRESS_DISPLAY'
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="card-map"',
'     style="width:100%;height:300px"',
'     data-center="[&LONGITUDE., &LATITUDE.]"',
'     data-background="default"',
'     data-zoom="16"',
'     data-marker="true"',
'     data-marker-color="var(--ut-palette-primary, #006BD8)"',
'     data-controls="false"',
'     data-interactive="false"',
'     data-tooltip="&ADDRESS_DISPLAY.">',
'</div>'))
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(340224415071513927)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(1026963214126005922)
,p_button_name=>'CREATE_OPTIONS_MAP'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(340158625274470030)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create Options Map'
,p_button_position=>'COPY'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(340225136353514926)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(1026964004449006923)
,p_button_name=>'CREATE_ATTRIBUTES_MAP'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(340158625274470030)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create Attributes Map'
,p_button_position=>'COPY'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(340226307932517518)
,p_name=>'Create Options Map'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(340224415071513927)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(340226706963517518)
,p_event_id=>wwv_flow_api.id(340226307932517518)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#optionsMap").miniMap({',
'    center: [-122.26516, 37.52938],',
'    background: "osm-bright",',
'    zoom: 14,',
'    marker: true,',
'    markerColor: "red",',
'    controls: true,',
'    interactive: true,',
'    tooltip: "Oracle Redwood Shores"',
'});'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(340227109721518642)
,p_name=>'Create Attributes Map'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(340225136353514926)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(340227541229518643)
,p_event_id=>wwv_flow_api.id(340227109721518642)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#attributesMap").miniMap();'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(340227924339520042)
,p_name=>'Create Cards Map'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(1026965537434007792)
,p_bind_type=>'bind'
,p_bind_event_type=>'NATIVE_CARDS|REGION TYPE|tablemodelviewpagechange'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(340228313103520044)
,p_event_id=>wwv_flow_api.id(340227924339520042)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$( "div.card-map" ).miniMap();'
);
wwv_flow_api.component_end;
end;
/
