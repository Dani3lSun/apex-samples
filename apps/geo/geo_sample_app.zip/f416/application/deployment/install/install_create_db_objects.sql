prompt --application/deployment/install/install_create_db_objects
begin
--   Manifest
--     INSTALL: INSTALL-Create DB Objects
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-19'
,p_default_workspace_id=>7805442713131290
,p_default_application_id=>416
,p_default_id_offset=>0
,p_default_owner=>'DANIEL'
);
wwv_flow_api.create_install_script(
 p_id=>wwv_flow_api.id(340200092095476467)
,p_install_id=>wwv_flow_api.id(340199944174474299)
,p_name=>'Create DB Objects'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from user_objects',
' where object_type = ''TABLE''',
'   and object_name = ''EBA_SPATIAL_ADDRESSES'''))
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create sequence eba_spatial_id',
'/',
'',
'create table eba_spatial_addresses(',
'  id                  number(10) not null,',
'  addr_name           varchar2(200) not null,',
'  addr_street         varchar2(200),',
'  addr_postal_code    varchar2(20),',
'  addr_city           varchar2(200) not null,',
'  addr_state          varchar2(200),',
'  addr_country        varchar2(200) not null,',
'  addr_type           varchar2(20) not null',
'                      constraint eba_spatial_addresses_type_ck',
'                      check (addr_type in (''SUPPLIER'', ''CUSTOMER'')),',
'  owner               varchar2(200),',
'  datetime            timestamp with time zone,',
'  addr_location       mdsys.sdo_geometry,',
'  constraint eba_spatial_addresses_pk primary key (id)',
')',
'/',
'',
'create trigger eba_spatial_addresses_bi',
'before insert on eba_spatial_addresses',
'for each row',
'begin',
'  select eba_spatial_id.nextval into :new.id from dual;',
'  :new.datetime := systimestamp;',
'end;',
'/',
'    ',
'insert into eba_spatial_addresses (addr_name, addr_street, addr_city, addr_country, addr_type, owner, addr_location)',
'values (''Oracle Corporation'', ''500, Oracle Parkway'', ''Redwood City'', ''US'', ''CUSTOMER'', ''EBA'', mdsys.SDO_GEOMETRY(2001, 4326, mdsys.SDO_POINT_TYPE(-122.26226, 37.53087, NULL), NULL, NULL))',
'/',
'',
'insert into eba_spatial_addresses (addr_name, addr_street, addr_postal_code, addr_city, addr_country, addr_type, owner, addr_location)',
'    values (''Oracle Deutschland B.V. & Co KG'', ''Riesstr. 25'', ''80992'', unistr(''M\00FCnchen''), ''DE'', ''CUSTOMER'', ''EBA'', mdsys.SDO_GEOMETRY(2001, 4326, mdsys.SDO_POINT_TYPE(11.5367, 48.1801, NULL), NULL, NULL))',
'/',
'    ',
'insert into eba_spatial_addresses (addr_name, addr_street, addr_postal_code, addr_city, addr_country, owner, addr_type, addr_location, addr_state)',
'values (''Oracle UK'', ''510 Oracle Parkway'', ''RG6 1'', ''Reading'', ''UK'', ''EBA'', ''CUSTOMER'', mdsys.SDO_GEOMETRY(2001, 4326, mdsys.SDO_POINT_TYPE(-0.9382, 51.46, NULL), NULL, NULL), ''Berkshire'')',
'/',
'',
'insert into eba_spatial_addresses (addr_name, addr_street, addr_postal_code, addr_city, addr_country, owner, addr_type, addr_location)',
'values (''Oracle Austria'', ''Wagramer Str. 17-19'', ''1220'', ''Wien'', ''AT'', ''EBA'', ''SUPPLIER'', mdsys.SDO_GEOMETRY(2001, 4326, mdsys.SDO_POINT_TYPE(16.4201, 48.2341, NULL), NULL, NULL))',
'/',
'',
'commit',
'/',
'',
'begin',
'  apex_spatial.insert_geom_metadata_lonlat(',
'    p_table_name   => ''EBA_SPATIAL_ADDRESSES'',',
'    p_column_name  => ''ADDR_LOCATION''',
'  );',
'end;',
'/',
'',
'create index EBA_SPATIAL_ADDRESSES_SX on EBA_SPATIAL_ADDRESSES (ADDR_LOCATION)',
'indextype is MDSYS.SPATIAL_INDEX',
'/',
''))
);
wwv_flow_api.component_end;
end;
/
